
# PCL 2 Exercise 3: JSON converter

## Introduction
In this exercise, you will develop a JSON converter to process a large JSON file, selectively writing parts of its contents to an XML file in a memory-efficient manner. The objective is to handle large data without overloading system memory, ensuring your application performs optimally under constraints.

### Evaluation Criteria
This exercise is part of the course assessment and will contribute three points towards your final grade. Ensure you adhere to the following to achieve full marks:
- Your implementation is correct and produces the correct output.
- Your implementation fulfills the specified memory usage requirements.
- Your code is reasonably well-structured and readable.

### Submission
**This is a graded exercise.** Submit your exercise through GitLab by **May 21st at 23:59**. Late submissions will result in zero points. Fork the exercise repository to start, and remember to include your name and matriculation number in all files. Set up your GitLab account to add tutors as 'Reporters' and finalize your submission by creating a release. Consult the `instructions.pdf` in OLAT for detailed submission guidelines.

### Important Notes
- Enhance your code's understandability with relevant comments and docstrings.
- In order to work with large files (>100MB) on GitLab, you need to use Git Large File Storage (https://git-lfs.com/) 

### git-lfs Setup
1. Install [git-lfs](https://git-lfs.com/) (on Mac: `brew install git-lfs`; on Debian/Ubuntu: `apt-get install git-lfs`)
2. Initialize git-lfs: `git lfs install`
3. Navigate to your repository: `cd your_repository_name`
4. Track JSON and XML files with LFS:
   1. `git lfs track "*.json"`
   2. `git lfs track "*.xml"`
5. Commit and push .gitattributes along with your changes.

### Deliverables
- Your solution in the converter.py file
- Your logged statistics (added to the repository as a `.txt` file) after calling the script with:  
  ```bash
  python converter.py --json_file review_large.json --xml_train <your_train_filename.xml> --xml_test <your_test_filename.xml> -n 3000
  ```
  (If you did not manage to finish Part B, just use the command from Part A)

## Exercise Tasks

### Part A (2 points)

1. **Convert JSON to XML**: Implement the `converter.py` script to sequentially process the JSON files and convert the reviews to XML format. Each XML-review must adhere to the following format:

```xml
<review>
  <review_id>OAhBYw8IQ6wlfw1owXWRWw</review_id>
  <user_id>1C2lxzUo1Hyye4RFIXly3g</user_id>
  <business_id>BVndHaLihEYbr76Z0CMEGw</business_id>
  <ratings stars="5.0" useful="0" funny="0" cool="0"/>
  <text>Great place for breakfast! I had the waffle, which was fluffy and perfect, and home fries which were nice and smashed and crunchy. Friendly waitstaff. Will definitely be back!</text>
  <date year="2014" month="10" day="11" weekday="Saturday"/>
</review>
```

2. **Filter out weekdays**: Only include reviews in the output that have been posted on a Weekend (Saturday or Sunday).

3. **Command line interface**: Add a CLI so your script can be called from the command line. Your script must be callable with the following arguments:

```bash
python converter.py --json_file review_large.json --xml <your_filename.xml>
```

4. **Statistics**: Count the number of reviews you read from the JSON file and the number of reviews you wrote to the XML file.
Use the `logging` library to log these numbers. Your log should look similar to this:
```txt
INFO:root:Processed 3214654 reviews from file review_large.json
INFO:root:Written 1237524 reviews to reviews_converted.xml
```

**Hints:** 
- You only need to iterate over the JSON file once.
- Use appropriate libraries for sequential processing (for reading **and** writing files) as discussed in the lecture. **Never** write an XML file without using an XML library (like in the bad example on page 73 of Lecture 8 (Text Encoding)).
- Test your solution on the small file first (`review.json`). Compare the output with the provided sample file (`review.xml`) to see if your implementation is correct. Then use the large file (`review_large.json`) to check if your solution is memory efficient.
- Use a memory profiler or your system’s task manager to monitor the memory usage of the python process. It's possible to achieve this task with less than 20MiB of memory. If your memory usage is significantly higher, or you observe sudden memory spikes, it's likely that your code is not optimized enough.

### Part B (1 point) (this will be covered in the lecture on May 15th 2024)

1. Extend your script and implement the **Reservoir Sampling** algorithm. Refactor your code so the reviews that were posted on a weekend are randomly split into a training set and test set as you are iterating over the JSON input file. Adapt the script so the converted reviews are written to two files: `--xml_train` and `--xml_test`. 

2. Add the following arguments to the CLI:
    - `--xml_test`: The output file for the test set in xml format.
    - `-n`: The number of items in the reservoir. These are the reviews that will be written to `--xml_test`.
    - Rename the argument `--xml` to `--xml_train`. This is the output file for the train set in xml format.

3. Update the logging: The number of reviews read from the JSON file, the number of reviews written to the test xml and number of reviews written to the train xml must be logged. Your log should look similar to this:
```txt
INFO:root:Processed 3214654 reviews from file review_large.json
INFO:root:Written 1234524 reviews to train.xml
INFO:root:Written 3000 test reviews to xml test.xml
```

**Hints:** 
- You still only need to iterate over the file once. The memory requirement should not increase significantly (for small values of `-n`). For example, we used less than 35 MiB with a reservoir size of 3000.
- Make sure the sum of the number of reviews in `--xml_train` and `--xml_test` is the same as the number of reviews that you wrote to the xml file in task A. No review should appear in both xml-files.
- If you set the reservoir size to 0 (`-n`) the `--xml_train` file should look identical to the xml file generated in task A.


## Rules for Using Generative AI

- **Allowed Tools:** You are permitted to use generative AI tools such as GitHub Copilot and ChatGPT.

- **Code Attribution:**
  - **Single Lines:** You do not need to cite the AI tool for single lines of code completed by GitHub Copilot.
  - **Multiple Lines or Functions:** You must include a comment in your code stating the tool used and the prompt you provided. For example:
    ```python
    # Function generated by ChatGPT (with minor modifications)
    # Prompt used: "Add a method to find duplicate lines" + the rest of my class definition
    def find_duplicate_lines(self):
        seen_lines = set()
        duplicate_lines = []
        for line in self.lines:
            if line in seen_lines:
                duplicate_lines.append(line)
            else:
                seen_lines.add(line)
        return duplicate_lines
    ```

- **Responsibility:** It is your responsibility to ensure that any code generated by AI tools functions correctly and meets the exercise requirements.

- **Service Availability:** There is no guarantee that services like ChatGPT will be available at all times. You will not be eligible for a deadline extension if you are unable to access your preferred AI tool.
